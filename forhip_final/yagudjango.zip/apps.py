from django.apps import AppConfig


class YagudjangoConfig(AppConfig):
    name = 'yagudjango'
