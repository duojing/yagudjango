from django.shortcuts import render, get_object_or_404, redirect
from yagudjango.models import Gujang, Block, Seat, Comment
from django.views.generic import DetailView
from yagudjango.forms import CommentForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required

def gujang_list(request):
    return render(request, 'yagudjango/yagudjango_main.html')

def gujang_detail(request, pk):
    gujang = Gujang.objects.get(pk=pk)
    return render(request, 'yagudjango/yagudjango_stdm.html',{
        'gujang': gujang,
    })

def block_detail(request, pk, block_name) :
    gujang = Gujang.objects.get(pk=pk)
    block_list = Block.objects.filter(stadium=gujang)
    block = block_list.first
    #block = block_list.get(block_name=block_name)
    return render(request, 'yagudjango/yagudjango_block.html', {
        'gujang' : gujang,
        'block_list' : block_list,
        'block' : block,
    })

# block_detail = DetailView.as_view(model=Block)

@login_required
def comment_new(request, post_pk):
    post = get_object_or_404(Block, pk=post_pk)

    if request.method =='POST':
        form = CommentForm(request.POST, request.FILES)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.user = request.user
            comment.post = post
            comment.save()
            if request.is_ajax():
                return render(request, 'yagudjango/_comment.html',{
                    'comment':comment,
                })
            messages.success(request, '새 댓글을 저장했습니다.')
            return redirect(comment.post)
    else:
        form = CommentForm()
    return render(request, 'yagudjango/comment_form.html',{
        'form':form,
    })

@login_required
def comment_edit(request, post_pk, pk):
    comment = get_object_or_404(Comment, pk=pk)

    if comment.user != request.user:
        messages.warning(request, '댓글 작성자만 수정할 수 있습니다.')
        return redirect(comment.post)

    if request.method == 'POST':
        form = CommentForm(request.POST, request.FILES, instance=comment)
        if form.is_valid():
            comment = form.save()
            messages.success(request, '기존 댓글을 수정했습니다.')
            return redirect(comment.post)

    else:
        form = CommentForm(instance=comment)
    return render(request, 'yagudjango/comment_form.html',{
        'form':form,
    })

@login_required
def comment_delete(request, post_pk, pk):
    comment = get_object_or_404(Comment, pk=pk)

    if comment.user != request.user:
        messages.warning(request, '댓글 작성자만 삭제할 수 있습니다.')
        return redirect(comment.post)

    if request.method == 'POST':
        comment.delete()
        messages.success(request, '댓글을 삭제했습니다.')
        return redirect(comment.post)
    return render(request, 'yagudjango/comment_confirm_delete.html',{
        'comment':comment,
    })
